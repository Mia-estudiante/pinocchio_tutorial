import rclpy
from rclpy.node import Node
from .mujoco_manager import MujocoManager
from .robot_interface.franka_handler import FrankaHandler
import mujoco
import mujoco.viewer
import time

class MujocoSimNode(Node):
    def __init__(self):
        super().__init__('mujoco_ros2_node')

        self.declare_parameter('model_path', '')
        self.declare_parameter('initial_qpos',[0.0])
        model_path = self.get_parameter('model_path').get_parameter_value().string_value
        init_qpos = self.get_parameter('initial_qpos').get_parameter_value().double_array_value
        
        self.manager = MujocoManager(model_path)
        self.model = self.manager.get_model()
        self.data = self.manager.get_data()
        joint_names = self.manager.get_joint_names()
        self.robot = FrankaHandler(self, self.model, self.data, base_index=0,
                                           robot_joint_names=joint_names, init_pose=init_qpos)

    def run(self):
        with mujoco.viewer.launch_passive(self.model, self.data) as viewer:
            while rclpy.ok() and viewer.is_running():
                self.robot.publish_joint_state()
                # self.robot.publish_ft_sensor()
                self.robot.apply_commands()
                # mujoco.mj_step(self.model, self.data)
                mujoco.mj_forward(self.model, self.data)
                viewer.sync()
                rclpy.spin_once(self, timeout_sec=0.01)

def main():
    rclpy.init()
    node = MujocoSimNode()
    try:
        node.run()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
