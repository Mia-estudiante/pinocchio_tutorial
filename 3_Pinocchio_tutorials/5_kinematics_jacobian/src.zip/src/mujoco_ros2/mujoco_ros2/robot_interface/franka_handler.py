from rclpy.node import Node
from rclpy.logging import get_logger
from sensor_msgs.msg import JointState
from geometry_msgs.msg import WrenchStamped
from std_msgs.msg import Bool
import numpy as np
from numpy import nan_to_num, sum
from numpy.linalg import pinv

import mujoco


import os

import pinocchio as pin
from pinocchio import RobotWrapper
from pinocchio.utils import *

from ament_index_python.packages import get_package_share_directory


class state():
    def __init__(self):
        self.q: np.array
        self.v: np.array
        self.a: np.array
        self.q_des: np.array
        self.v_des: np.array
        self.a_des: np.array
        self.q_ref: np.array
        self.v_ref: np.array

        self.acc: np.array
        self.tau: np.array
        self.torque: np.array
        self.v_input: np.array

        self.nq: np.array
        self.nv: np.array
        self.na: np.array

        self.id: np.array
        self.G: np.array
        self.M: np.array
        self.J: np.array
        self.M_q: np.array
        self.oMi : pin.SE3


class pandaWrapper(RobotWrapper):
    def __init__(self):
        package_name = "franka_description"
        urdf_file_path = os.path.join(get_package_share_directory(package_name), "robots", "panda", "panda.urdf")
        self.__robot = self.BuildFromURDF(urdf_file_path)

        self.data, self.__collision_data, self.__visual_data = \
            pin.createDatas(self.__robot.model, self.__robot.collision_model, self.__robot.visual_model)
        self.model = self.__robot.model
        self.state = state()

        self.__ee_joint_name = "panda_joint7"
        self.state.id = self.index(self.__ee_joint_name)

        self.state.nq = self.__robot.nq
        self.state.nv = self.__robot.nv
        self.state.na = self.__robot.nv

        self.state.q = zero(self.state.nq)
        self.state.v = zero(self.state.nv)
        self.state.a = zero(self.state.na)
        self.state.acc = zero(self.state.na)
        self.state.tau = zero(self.state.nv)

        self.state.oMi = pin.SE3()


    def computeAllTerms(self):
        pin.computeAllTerms(self.model, self.data, self.state.q, self.state.v)
        # pin.compute
        self.state.G = self.nle(self.state.q, self.state.v)     # NonLinearEffects
        self.state.M = self.mass(self.state.q)                  # Mass
        self.state.J = self.getJointJacobian(self.state.id)
        self.state.a = pin.aba(self.model, self.data, self.state.q, self.state.v, self.state.tau)
        self.state.oMi = self.data.oMi[self.state.id]




class FrankaHandler:
    def __init__(self, node: Node, model, data, base_index, robot_joint_names,init_pose):
        self.node = node
        self.model = model
        self.data = data
        self.base_index = base_index

        # chan
        self.frankaWrapper = pandaWrapper()
        self.logger = get_logger("Mujoco_Robot_Handler")
    

        # 프랑카 조인트 이름만 사용
        self.robot_joints = robot_joint_names

        # 센서 인덱스 및 정보
        # self.force_sensor_index = self.model.sensor(f"franka_force").id * 3
        # self.torque_sensor_index = self.model.sensor(f"franka_torque").id * 3
        # self.node.get_logger().info(f"[Franka] force_sensor_index: {self.force_sensor_index}")
        # self.node.get_logger().info(f"[Franka] torque_sensor_index: {self.torque_sensor_index}")

        # 퍼블리셔 및 서브스크라이버 설정
        self.joint_pub = node.create_publisher(JointState, "/mjc/joint_states", 10)
        self.ft_pub = node.create_publisher(WrenchStamped, "/ft_sensor_state", 10)

        node.create_subscription(JointState, "/effort_controller/commands", self.torque_callback, 10)
        node.create_subscription(Bool, "/grasp_flag", self.grasp_callback, 10)
        self.logger.info(f"init : {init_pose}")
        self.set_initial_pose(init_pose)
        self.velocity_cmd = None
        self.torque_cmd = None

    def set_initial_pose(self,init_pose):

        initial_qpos = init_pose
        self.data.qpos[:] = initial_qpos
        self.data.qvel[:] = np.zeros_like(self.data.qvel)

        # chan
        self.frankaWrapper.state.q = self.data.qpos[:7].copy()
        self.frankaWrapper.state.v = self.data.qvel[:7].copy()
        self.frankaWrapper.computeAllTerms()
        


    def grasp_callback(self, msg: Bool):
        # 손가락 조인트에 force_value를 적용
        force_value = -100.0 if msg.data else 50.0
        self.node.get_logger().info(f"[Franka] Received grasp flag: {msg.data} -> Applying force {force_value} N")
        for name in self.robot_joints:
            if "finger" in name:
                try:
                    act_id = self.model.actuator(name).id
                    self.data.ctrl[act_id] = force_value
                    self.node.get_logger().info(f"[Franka] Actuator '{name}' set to {force_value} N")
                except Exception as e:
                    self.node.get_logger().warn(f"[Franka] actuator '{name}' control failed: {e}")

    def torque_callback(self, msg):
        self.torque_cmd = msg

    def publish_joint_state(self):
        msg = JointState()
        msg.header.stamp = self.node.get_clock().now().to_msg()
        # 프랑카 조인트만 처리
        for jname in self.robot_joints:
            joint_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, jname)
            qpos_index = self.model.jnt_qposadr[joint_id]
            msg.position.append(self.data.qpos[qpos_index])
            jid = self.model.joint(jname).id
            msg.velocity.append(self.data.qvel[jid])
            qdd= self.data.qfrc_actuator[jid]
            msg.effort.append(qdd)

        # chan
        self.frankaWrapper.state.q = np.array(msg.position[:7])
        self.frankaWrapper.state.v = np.array(msg.velocity[:7])            
        self.frankaWrapper.computeAllTerms()

        msg.name = self.robot_joints
        self.joint_pub.publish(msg)

    def apply_commands(self):
        if self.torque_cmd:
            # self.data.ctrl[act_id] = self.torque_cmd.effort[i]
            self.data.qpos = np.array(self.torque_cmd.position)
            # for i, name in enumerate(self.torque_cmd.name):
            #     if name in self.robot_joints:
            #         try:
            #             jid = self.model.joint(name).id
            #             act_id = self.model.actuator(name).id
            #             self.data.ctrl[act_id] = self.torque_cmd.effort[i]
            #         except Exception as e:
            #             self.node.get_logger().warn(f"[Franka] actuator '{name}' control failed: {e}")


    #-----------------------------------FT sensor----------------------------------------
    def adjoint_transform(self, sensor_pos, com_pos, R_sensor):
        r = sensor_pos - com_pos
        skew_r = np.array([
            [0, -r[2], r[1]],
            [r[2], 0, -r[0]],
            [-r[1], r[0], 0]
        ])
        AdT = np.zeros((6, 6))
        AdT[:3, :3] = R_sensor
        AdT[3:, :3] = R_sensor @ skew_r
        AdT[3:, 3:] = R_sensor
        return AdT
    
    def compute_internal_wrench_for_body_and_children(self, root_body_name, zero_acc=False):
        root_body_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, root_body_name)
        sensor_body_id = root_body_id
        nbody = self.model.nbody
        descendants = []

        def get_children(parent_id):
            for i in range(nbody):
                if self.model.body_parentid[i] == parent_id:
                    descendants.append(i)
                    get_children(i)

        descendants.append(root_body_id)
        get_children(root_body_id)

        wrench_total = np.zeros(6)
        sensor_pos = self.data.xpos[sensor_body_id]
        R_sensor = self.data.xmat[sensor_body_id].reshape(3, 3).T

        for body_id in descendants:
            mass = self.model.body_mass[body_id]
            R_body = self.data.xmat[body_id].reshape(3, 3)
            inertia_diag = self.model.body_inertia[body_id]
            I = R_body @ np.diag(inertia_diag) @ R_body.T

            if zero_acc:
                a_lin = np.zeros(3)
                a_ang = np.zeros(3)
                omega = np.zeros(3)
            else:
                a_lin = self.data.cacc[body_id, :3]
                a_ang = self.data.cacc[body_id, 3:]
                omega = self.data.cvel[body_id, 3:]

            f_inertial = mass * a_lin
            f_gravity = mass * np.array(self.model.opt.gravity)
            f_body = f_inertial + f_gravity
            tau_body = I @ a_ang + np.cross(omega, I @ omega)

            wrench_com = np.hstack([f_body, tau_body])
            com_pos = self.data.xpos[body_id] + R_body @ self.model.body_ipos[body_id]
            AdT = self.adjoint_transform(sensor_pos, com_pos, R_sensor)
            wrench_at_sensor = AdT @ wrench_com
            wrench_total += wrench_at_sensor

        return wrench_total[:3], wrench_total[3:]
    
    

    def publish_ft_sensor(self):
        f_static, tau_static = self.compute_internal_wrench_for_body_and_children("panda_link7", zero_acc=True)
        f_measured = self.data.sensordata[self.force_sensor_index : self.force_sensor_index + 3]
        t_measured = self.data.sensordata[self.torque_sensor_index : self.torque_sensor_index + 3]
        f_corrected = f_measured + f_static
        t_corrected = t_measured - tau_static

        msg = WrenchStamped()
        msg.header.stamp = self.node.get_clock().now().to_msg()
        msg.header.frame_id = "franka_ft_sensor"
        msg.wrench.force.x = f_corrected[0]
        msg.wrench.force.y = f_corrected[1]
        msg.wrench.force.z = f_corrected[2]
        msg.wrench.torque.x = t_corrected[0]
        msg.wrench.torque.y = t_corrected[1]
        msg.wrench.torque.z = t_corrected[2]
        self.ft_pub.publish(msg)

    
