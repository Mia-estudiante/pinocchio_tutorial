import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, Command
from launch_ros.actions import Node
def generate_launch_description():
    mujoco_yaml_path = os.path.join(
        get_package_share_directory('rci_action_manager'),
        'config',
        'mujoco_params.yaml'
    )
    simulation_yaml_path = os.path.join(
        get_package_share_directory('rci_action_manager'),
        'config',
        'simulation_params.yaml'
    )

    # --- 1. 기본 설정 ---
    # GUI 슬라이더 사용 여부 (joint_state_publisher_gui 실행 여부)
    # 터미널에서 'use_gui:=false'로 비활성화 가능
    use_gui_arg = DeclareLaunchArgument(
        name='use_gui',
        default_value='true',
        description='Whether to use joint_state_publisher_gui')
    # RViz 설정 파일 경로 정의
    pkg_name = 'franka_description'  # (주의: 실제 패키지 이름으로 변경)
    pkg_share_dir = get_package_share_directory(pkg_name)
    # (주의: 실제 .rviz 파일 경로로 변경)
    rviz_config_file = os.path.join(pkg_share_dir, 'rviz', 'panda.rviz')
    
    # --- 2. 로봇 모델(URDF) 로드 ---
    # (주의: 실제 .xacro 또는 .urdf 파일 경로로 변경)
    urdf_file_path = os.path.join(pkg_share_dir, 'robots', 'panda','panda.urdf.xacro')
    # xacro 파일을 처리하여 'robot_description' 파라미터 내용 생성
    robot_description_content = Command([
        'xacro ', urdf_file_path
    ])
    robot_description_param = {
        'robot_description': robot_description_content
    }

    # --- 3. 노드 정의 ---
    # (필수) Robot State Publisher
    # 'robot_description' 파라미터를 읽고, 'joint_states' 토픽을 구독하여
    # TF 데이터를 '/tf' 토픽으로 발행합니다.
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[robot_description_param]
    )
    joint_state_publisher_gui_node = Node(
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui',
        )
    # (필수) RViz2
    # TF와 'robot_description' 등을 구독하여 시각화합니다.
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config_file]
    )
    # MuJoCo
    mjc_node = Node(
            package='mujoco_ros2',
            executable='mujoco_ros2_node',
            name='mujoco_ros2_node',
            output='screen',
            parameters=[mujoco_yaml_path],
    )
    # Simulation Node
    sim_node = Node(
            package='rci_action_manager',
            executable='simulation_node',
            name='simulation_node',
            output='screen',
            parameters=[simulation_yaml_path],
    )

    # --- 4. 런치 설명 반환 ---
    return LaunchDescription([
        use_gui_arg,
        robot_state_publisher_node,
        joint_state_publisher_gui_node,
        rviz_node,
        mjc_node,
        sim_node
    ])