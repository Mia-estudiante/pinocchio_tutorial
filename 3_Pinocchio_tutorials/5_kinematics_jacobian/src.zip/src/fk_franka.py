import numpy as np
from copy import deepcopy

EPS = 1e-12

def pretty_print(arr, decimals=3):
    with np.printoptions(precision=decimals, suppress=True, floatmode='fixed'):
        print(arr)

class FrankaKinematicsCalculator:
    def __init__(self):
        '''
        * URDF 정보 *
        1. Origin: Parent frame 기준
        2. Axis: Local frame 기준(자기 자신)
        
        * FK 순서 *
        Step 1. World frame 기준 Chain list
        Step 2. World frame 기준 Screw list
        Step 3. Forward Kinematics
        '''
        
        self.urdf_origin_rpy = [[0,0,0],
                                [-np.pi/2, 0, 0],
                                [np.pi/2, 0, 0],
                                [np.pi/2, 0, 0],
                                [-np.pi/2, 0, 0],
                                [np.pi/2, 0, 0],
                                [np.pi/2, 0, 0]]
        
        self.urdf_origin_xyz = [[0,0,0.333],
                                [0,0,0],
                                [0, -0.316, 0],
                                [0.0825, 0, 0],
                                [-0.0825, 0.384, 0],
                                [0,0,0],
                                [0.088, 0, 0]]
        
        self.urdf_axis = [[0,0,1], 
                          [0,0,1],
                          [0,0,1],
                          [0,0,1],
                          [0,0,1],
                          [0,0,1],
                          [0,0,1]]

        # RPY -> Rotation Matrix
        self.rots = []
        for i in range(len(self.urdf_origin_rpy)):
            rpy = np.array(self.urdf_origin_rpy[i])
            rot = self.rpy_to_rot(rpy)
            self.rots.append(rot)

        # Chain list (World)
        self.chain_list = [] #wT1, wT2, ..., wT7
        T = np.eye(4)

        for i in range(len(self.urdf_origin_xyz)):
            T_chain = np.eye(4)
            T_chain[:3, :3] = np.array(self.rots[i])
            T_chain[:3, 3] = np.array(self.urdf_origin_xyz[i])
            T = T @ T_chain
            self.chain_list.append(T)

        self.M = deepcopy(T)  # eef pose

        # World axis
        self.world_axis = []
        for i in range(len(self.urdf_axis)):
            R = self.chain_list[i][:3, :3]
            local_axis = np.array(self.urdf_axis[i])
            world_axis = R @ local_axis
            self.world_axis.append(world_axis)

        # World screws
        self.world_screws = []
        for i in range(len(self.world_axis)):
            w = self.world_axis[i]
            p = self.chain_list[i][:3, 3] 
            v = -np.cross(w, p)
            S = np.hstack((w, v))
            self.world_screws.append(S)

    def rpy_to_rot(self, rpy):
        """
        Convert Roll-Pitch-Yaw (r, p, y) to a 3x3 rotation matrix.
        R = Rz(yaw) * Ry(pitch) * Rx(roll)
        """
        roll, pitch, yaw = rpy[0], rpy[1], rpy[2] 
        cr = np.cos(roll)
        sr = np.sin(roll)
        cp = np.cos(pitch)
        sp = np.sin(pitch)
        cy = np.cos(yaw)
        sy = np.sin(yaw)

        # Rotation about x-axis (Roll)
        Rx = np.array([
            [1, 0, 0],
            [0, cr, -sr],
            [0, sr, cr]
        ])

        # Rotation about y-axis (Pitch)
        Ry = np.array([
            [cp, 0, sp],
            [0, 1, 0],
            [-sp, 0, cp]
        ])

        # Rotation about z-axis (Yaw)
        Rz = np.array([
            [cy, -sy, 0],
            [sy, cy, 0],
            [0, 0, 1]
        ])

        # Z * Y * X
        R = Rz @ Ry @ Rx

        return R
    
    def skew(self, omega):
        """
        Generate a skew-symmetric matrix from a 3D vector.
        """
        return np.array([[0, -omega[2], omega[1]],
                         [omega[2], 0, -omega[0]],
                         [-omega[1], omega[0], 0]])
    
    def exp_so3(self, omega, theta):
        wnorm = np.linalg.norm(omega)
        if wnorm < EPS:
            return np.eye(3)
        w = omega / wnorm
        K = self.skew(w)
        th = wnorm * theta
        R = np.eye(3) + np.sin(th) * K + (1 - np.cos(th)) * (K @ K)
        return R
    
    def matrix_V(self, omega, theta):
        wnorm = np.linalg.norm(omega)
        if wnorm < EPS:
            return np.eye(3) * theta
        w = omega / wnorm
        K = self.skew(w)
        th = wnorm * theta
        V = (np.eye(3) * theta
            + (1 - np.cos(th)) / (wnorm**2) * K
            + (th - np.sin(th)) / (wnorm**3) * (K @ K))
        return V

    def exp_se3(self, S, theta):
        omega = np.array(S[:3], dtype=float)
        v = np.array(S[3:], dtype=float)
        wnorm = np.linalg.norm(omega)

        if wnorm < EPS:
            R = np.eye(3)
            p = v * theta
        else:
            R = self.exp_so3(omega, theta)
            V = self.matrix_V(omega, theta)
            p = V @ v

        T = np.eye(4)
        T[:3, :3] = R
        T[:3, 3] = p
        return T
    
    def compute_fk(self, thetas=[0,0,0,0,0,0,0]):
        T = np.eye(4)
        for S, th in zip(self.world_screws, thetas):
            T = T @ self.exp_se3(S, th)
        T = T @ self.chain_list[-1]
        return  T
    
    def adj_se3(self, T):
        """
        Compute the adjoint representation of a homogeneous transformation matrix T.
        """
        R = T[:3, :3]
        p = T[:3, 3]
        p_skew = self.skew(p)

        Ad = np.zeros((6,6))
        Ad[:3, :3] = R
        Ad[3:, 3:] = R
        Ad[3:, :3] = p_skew @ R

        return Ad
    
    def inv_homogeneous(self, T):
        R = T[:3, :3]
        p = T[:3, 3]
        T_inv = np.eye(4)
        T_inv[:3, :3] = R.T
        T_inv[:3, 3] = -R.T @ p
        return T_inv
    
    def compute_jacobian(self, thetas=[0,0,0,0,0,0,0]):
        exp_list = []
        for S, th in zip(self.world_screws, thetas):
            exp_S = self.exp_se3(S, th)
            exp_list.append(exp_S)

        # Jacobian list
        J_list = []
        T = np.eye(4)
        for i in range(len(self.world_screws)):
            if i > 0:
                T = T @ exp_list[i-1]   # 첫 조인트는 변환 없음
            J = self.adj_se3(T) @ self.world_screws[i]
            J_list.append(J)
        J_tmp = np.column_stack(J_list)

        # Spatial jacobian
        J = np.zeros((6,7))
        J[:3, :7] = deepcopy(J_tmp[3:, :])
        J[3:, :7] = deepcopy(J_tmp[:3, :])

        # Local jacobian
        w_T_eef = self.compute_fk(thetas=thetas)
        eef_T_w = self.inv_homogeneous(w_T_eef)
        Ad_eef = self.adj_se3(eef_T_w)
        J_Local_tmp = Ad_eef @ J_tmp

        J_Local = np.zeros((6,7))
        J_Local[:3, :7] = deepcopy(J_Local_tmp[3:, :])
        J_Local[3:, :7] = deepcopy(J_Local_tmp[:3, :])

        return J, J_Local    

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState

class CustomFKNode(Node):
    def __init__(self):
        super().__init__('custom_fk_node')
        self.kinematics_solver = FrankaKinematicsCalculator()
        self.get_logger().info("Custom FK Node initialized")

        self.rviz_sub = self.create_subscription(
                        JointState, "/joint_states", self.rviz_state_callback, 10)
        
        self.timer = self.create_timer(1.0, self.timer_callback)
        self.joint_positions = None

        print("Custom FK Node is running...")

    def rviz_state_callback(self, msg):
        self.joint_positions = np.array(msg.position[:7])
        
    def timer_callback(self):
        if not self.joint_positions is None:
            # 1. Forward Kinematics
            T = self.kinematics_solver.compute_fk(thetas=self.joint_positions.tolist())
            rot = T[:3, :3] 
            trans = T[:3, 3]
            self.get_logger().info(f"Custom FK Reuslt: \n" + f"Rot : {rot} \n" + f"Trans : {trans}")

            # 2. Jacobian
            Spatial_Jacob, Local_Jacob = self.kinematics_solver.compute_jacobian(thetas=self.joint_positions.tolist())
            self.get_logger().info(f"Custom Jacobian (WORLD): \n")
            pretty_print(Spatial_Jacob, decimals=3)
            self.get_logger().info(f"Custom Jacobian (LOCAL): \n")
            pretty_print(Local_Jacob, decimals=3)

def main(): 
    rclpy.init()
    node = CustomFKNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
