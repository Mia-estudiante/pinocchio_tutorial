import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState

import numpy as np
import pinocchio as pin

from rci_action_manager.script.robot.pandaWrapper import pandaWrapper

def pretty_print(arr, decimals=3):
    """
    Numpy array를 소수점 N째자리까지 예쁘게 출력하는 함수.
    """
    with np.printoptions(precision=decimals, suppress=True, floatmode='fixed'):
        print(arr)

class Simulation(Node):
    def __init__(self):
        super().__init__('simulation_node')

        self.declare_parameter('model_path', '')
        self.declare_parameter('joint_names', [''])
        model_path = self.get_parameter('model_path').get_parameter_value().string_value
        self.joint_names = self.get_parameter("joint_names").get_parameter_value().string_array_value
        self.joint_state_ready = False
        
        self.robot = pandaWrapper()

        # 모델 로딩
        self.model = pin.buildModelFromUrdf(str(model_path))
        self.data = self.model.createData()

        # 상태 변수 초기화
        self.q = np.zeros(self.model.nq)
        self.v = np.zeros(self.model.nv)
        self.G = np.zeros(self.model.nv)

        print(self.model.nv)


        self.sub = self.create_subscription(JointState, "/mjc/joint_states", self.joint_state_callback, 10)
        self.rviz_sub = self.create_subscription(JointState, "/joint_states", self.rviz_state_callback, 10)
        self.pub = self.create_publisher(JointState, "/effort_controller/commands", 10)

        self.get_logger().info("Simulation Node Initialized")

        # 루프 타이머 설정 (1000Hz)
        # self.create_timer(0.1, self.control_loop)

    def joint_state_callback(self, msg):
        self.q = np.array(msg.position[:self.model.nq])
        self.v = np.array(msg.velocity[:self.model.nv])

        self.joint_state_ready = True
        self.robot.state.q = self.q.copy()
        self.robot.state.v = self.v.copy()
        self.robot.computeAllTerms()

        print("Jacob LOCAL: \n")
        pretty_print(self.robot.state.J)
        print("\n")
        print("Jacob WORLD: \n")
        pretty_print(self.robot.state.J_w)

    def rviz_state_callback(self, msg):
        self.des_q = np.array(msg.position[:self.model.nq])
        torque_msg = JointState()
        torque_msg.name = self.joint_names
        torque_msg.position = self.des_q.tolist()
        self.pub.publish(torque_msg)

def main():
    rclpy.init()
    node = Simulation()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
